
// The app of that is this web-App
var app = angular.module('MainApp', ['ui.bootstrap','ui.grid', 'ui.grid.selection', 'ui.grid.cellNav', "ui.grid.pagination", 'ui.grid.cellNav', 'ui.grid.autoResize']);
