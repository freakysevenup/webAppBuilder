
// The controller responsible for the tables, hiding/showing the menu and selecteing rows
app.controller("tableCtrl", ['$rootScope', '$scope', '$http', '$interval', function($rootScope, $scope, $http, $interval)
{
    // The results page object stores the data which will be represented in the treeview table
    $scope.baselineResults = [];
    $scope.comparisonResults = [];
    $scope.diffResults = [];
    // The list of json files gathered from a json file will be stored here
    $scope.jsonFilesList = [];
    // The variable which will store the completed export data in csv format
    $scope.exportData = [];
    $scope.csvFiles = [];
    $scope.tableArray = [];
    // Set the default table height
    $scope.tableHeight = 430;
    // Fields for hiding/showing the elements on the page
    $scope.showButtons = false;
    $scope.showNav = true;
    $scope.showResultsBaseline = false;
    $scope.showResultsComparison = false;
    $scope.showResultsDiff = false;
    $scope.passWithReconciliation = false;
    $scope.testDescription = "";
    $scope.showthis = { };

    $scope.showthis.div = false;

    // Get the json file list
     $http.get("./jsonFiles/jsonFilesList.json")
            .then(function(json) 
            {
                json.data.forEach(function (row) 
                {
                    $scope.jsonFilesList.push(row);
                });
            });

    // grab this json file from the array and set the data for the table
    $scope.loadJsonFile = function(index)
    {

        //TODO: In this method, I have to check if $scope.passWithReconciliation is true
        // if its true than all results get passed through to the tables
        // if its false than only results whose reconciliation
        // This requires me to know about two things, did the test pass? and did it pass with reconciliation
        // This means I need to know abuot two tags for these values, and using those tags, determine whether or not 
        // to include them in the table data for any/all of the tables

        // NEED A COPY OF WHAT ITS GOING TO LOOK LIKE OR TO KNOW NOW WHAT THE TAGS WILL BE

        if ($scope.passWithReconciliation)
        {
            $scope.showThis = true;
        }

        var tempArray = [];
        var count = 0;
        $http.get($scope.jsonFilesList[index].filePath)
        .then(function(json) 
        {
            json.data.forEach(function (row) 
            {
                $scope.testDescription = json.data[0].description;
                // run through the json file
                if (json.data[count].newTable === true)
                {
                    // store the csv file Name for this table in an array
                    $scope.csvFiles.push(json.data[count].csvFileName);

                    if (typeof tempArray != 'undefined' && tempArray.length > 0)
                    {
                        // push the tempArray to the tables array
                        $scope.tableArray.push(tempArray);
                        tempArray = [];
                    }
                    else
                    {
                        // the tempArray isn't initialized yet so initialize it
                        tempArray = [];
                    }
                }
                else if (json.data[count].eof === true)
                {
                    // if this is the end of the file, store the data in tempArray into the table array
                    $scope.tableArray.push(tempArray);

                    // send the data in the first element of the tableArray to the baselineResults array
                    $scope.tableArray[0].forEach(function(row){
                        $scope.baselineResults.push(row);
                    });

                    if ($scope.tableArray.length > 1)
                    {
                        // if there are more tables in the table array then set those tables too the 
                        // comparisonResults and diffResults
                        $scope.tableArray[1].forEach(function(row){
                            $scope.comparisonResults.push(row);
                        });
                        $scope.tableArray[2].forEach(function(row){
                            $scope.diffResults.push(row);
                        });
                        $scope.showAllTables();
                    }
                    // Set the baselineResults object as the data for the treeView table
                    $scope.table.data = $scope.baselineResults;
                    $scope.resultsComparisonTable.data = $scope.comparisonResults;
                    $scope.resultsDiffTable.data = $scope.diffResults;
                }
                else
                {
                    // otherwise push the data to the tempArray

                    // IN HERE IS WHERE TO ADD THE LOGIC TO DETERMINE WHAT ROW TO ADD TO THE TABLES
                    if (!$scope.passWithReconciliation && (json.data[count].pass === true && json.data[count].reconciliation === true))
                    {
                        // Do nothing because I don't want that data in the table
                    }
                    else
                    {
                        tempArray.push(row);
                    }

                }
                count++;
            });
        });
    }; 

    // The baseliine/single table options settings
    $scope.table = 
    {
        data: 'baselineResults',
        rowHeight: 30,
        headerRowHeight: 30,
        footerRowHeight: 50,
        enableFiltering: true,
        paginationPageSizes: [10],
        paginationPageSize: 10,
        // columnDefs: [
        // { name: 'hierarchy', displayName: 'Level'},
        // { name: 'name'},
        // { name: 'bValue', displayName: 'Baseline'},
        // { name: 'cValue', displayName: 'Comparison' },
        // { name: 'diff', displayName: 'Diff'  },
        // { name: 'diffpercent', displayName: 'Diff%' },
        // { name: 'result', displayName: 'Result' },
        // { name: 'comments', displayName: 'Comments' }
        // ],
        onRegisterApi: function (gridApi) 
        {
            $scope.baselineGridApi = gridApi;
        }
    };

 // The comparison table options settings
    $scope.resultsComparisonTable = 
    {
        data: 'comparisonResults',
        rowHeight: 30,
        headerRowHeight: 30,
        footerRowHeight: 50,
        enableFiltering: true,
        paginationPageSizes: [10],
        paginationPageSize: 10,
        // columnDefs: [
        // { name: 'hierarchy', displayName: 'Level'},
        // { name: 'name'},
        // { name: 'bValue', displayName: 'Baseline'},
        // { name: 'cValue', displayName: 'Comparison' },
        // { name: 'diff', displayName: 'Diff'  },
        // { name: 'diffpercent', displayName: 'Diff%' },
        // { name: 'result', displayName: 'Result' },
        // { name: 'comments', displayName: 'Comments' }
        // ],
        onRegisterApi: function (gridApi) 
        {
            $scope.comparisonTableGridApi = gridApi;
        }
    };

 // The comparison table options settings
    $scope.resultsDiffTable = 
    {
        data: 'diffResults',
        rowHeight: 30,
        headerRowHeight: 30,
        footerRowHeight: 50,
        enableFiltering: true,
        paginationPageSizes: [10],
        paginationPageSize: 10,
        // columnDefs: [
        // { name: 'hierarchy', displayName: 'Level'},
        // { name: 'name'},
        // { name: 'bValue', displayName: 'Baseline'},
        // { name: 'cValue', displayName: 'Comparison' },
        // { name: 'diff', displayName: 'Diff'  },
        // { name: 'diffpercent', displayName: 'Diff%' },
        // { name: 'result', displayName: 'Result' },
        // { name: 'comments', displayName: 'Comments' }
        // ],
        onRegisterApi: function (gridApi) 
        {
            $scope.diffTableGridApi = gridApi;
        }
    };

    // Export onClick function called by button on html page
    $scope.exportCSV = function(index)
    {
        if ($scope.csvFiles[index] != null)
        {
            var filePath = "./" + $scope.csvFiles[index];
            $http({method: 'GET', url: filePath }).
            then(function(data, status, headers, config) {
                var anchor = angular.element('<a/>');
                anchor.attr({
                    href: 'data:attachment/csv;charset=utf-8,' + encodeURI(data),
                    target: '_blank',
                    download: 'attribution.csv'
                })[0].click();

            });
        }
    };

    // Dynamically set the height of the treeView table to either the height of the data or the height of 10 rows of data
    $scope.getTableHeight = function(index) 
    {
        var rowHeight = 30; 
        var headerHeight = 115; 

        switch(index)
        {
            case 0:
                if (($scope.table.data.length * rowHeight + headerHeight) > $scope.tableHeight || ($scope.table.data.length * rowHeight + headerHeight) == $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-1')[0]).css('height', $scope.tableHeight + 'px');
                }
                if (($scope.table.data.length * rowHeight + headerHeight) < $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-1')[0]).css('height', ($scope.table.data.length * rowHeight + headerHeight) + 'px');
                }
            break;
            case 1:
                if (($scope.resultsComparisonTable.data.length * rowHeight + headerHeight) > $scope.tableHeight || ($scope.resultsComparisonTable.data.length * rowHeight + headerHeight) == $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-2')[0]).css('height', $scope.tableHeight + 'px');
                }
                if (($scope.resultsComparisonTable.data.length * rowHeight + headerHeight) < $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-2')[0]).css('height', ($scope.resultsComparisonTable.data.length * rowHeight + headerHeight) + 'px');
                }
            break;
            case 2:
                if (($scope.resultsDiffTable.data.length * rowHeight + headerHeight) > $scope.tableHeight || ($scope.resultsDiffTable.data.length * rowHeight + headerHeight) == $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-3')[0]).css('height', $scope.tableHeight + 'px');
                }
                if (($scope.resultsDiffTable.data.length * rowHeight + headerHeight) < $scope.tableHeight)
                {
                    angular.element(document.getElementsByClassName('table-3')[0]).css('height', ($scope.resultsDiffTable.data.length * rowHeight + headerHeight) + 'px');
                }
            break;
        }
    };

    $scope.showAllTables = function(){
        $scope.showResultsComparison = $scope.showResultsComparison ? false : true;
        $scope.showResultsDiff = $scope.showResultsDiff ? false : true;
        $scope.comparisonTableGridApi.core.refresh();
        $scope.diffTableGridApi.core.refresh();
    }

    // Show or hide the treeView table, detailsTable and back button
    $scope.showTables = function(index)
    {
        $scope.showButtons = $scope.showButtons ? false : true;
        $scope.loadJsonFile(index);
        $scope.showResultsBaseline = $scope.showResultsBaseline ? false : true;
        $scope.showNav = $scope.showNav ? false : true;
        $scope.baselineGridApi.core.refresh();
    };

    // Show or hide the navigation menu
    $scope.returnToMenu = function()
    {
        $scope.showButtons = $scope.showButtons ? false : true;
        $scope.showResultsBaseline = $scope.showResultsBaseline ? false : true;
        $scope.showNav = $scope.showNav ? false : true;
        $scope.showResultsComparison = $scope.showResultsComparison ? false : true;
        $scope.showResultsDiff = $scope.showResultsDiff ? false : true;
    };
}]);